import random
import string

def generate_password(length):
    # Define character sets: letters, digits, and punctuation (symbols)
    letters = string.ascii_letters  # Includes both lowercase and uppercase letters
    digits = string.digits  # Numbers 0-9
    symbols = string.punctuation  # Special characters like !, @, #

    # Combine all character sets into one
    all_characters = letters + digits + symbols

    # Randomly select characters to form the password
    password = ''.join(random.choice(all_characters) for _ in range(length))

    return password

# Get user input for password length
password_length = int(input("Enter the length of the password: "))
password = generate_password(password_length)

# Display the generated password
print("Generated Password: password")
